package BST_A2;

public class BST_Node {
  String data;
  BST_Node left;
  BST_Node right;
  BST_Node parent;
  
  BST_Node(String data){ this.data=data; }

  // --- used for testing  ----------------------------------------------
  //
  // leave these 3 methods in, as is

  public String getData(){ return data; }
  public BST_Node getLeft(){ return left; }
  public BST_Node getRight(){ return right; }

  // --- end used for testing -------------------------------------------

  
  // --- fill in these methods ------------------------------------------
  //
  // at the moment, they are stubs returning false 
  // or some appropriate "fake" value
  //
  // you make them work properly
  // add the meat of correct implementation logic to them

  // you MAY change the signatures if you wish...
  // make the take more or different parameters
  // have them return different types
  //
  // you may use recursive or iterative implementations

  
  public boolean containsNode(String s){ 
	  if (s.equals(this.data)) {
		  return true;
	  } else if (s.compareTo(this.data) < 0) {
		  if (this.left == null) { return false;}
		  else {
		  return this.left.containsNode(s);
		  }
	  } else if (s.compareTo(this.data) > 0) {
		  if (this.right == null) { return false;}
		  else {		  
		  return this.right.containsNode(s);
		  }	  
	  }	  
	  return false; 
  }
  
  
  public boolean insertNode(String s){ 
	  if (this.containsNode(s) == true) {
		  return false;
	  
	  } else {
		  BST_Node newNode = new BST_Node(s);
		  if (s.compareTo(this.data) < 0) {
			  if (this.left == null) {
				  this.left = newNode;
				  this.left.parent = this;
				  return true;
			  } else {
				  return this.left.insertNode(s);
			  }
		  }	  
		  if (s.compareTo(this.data) > 0) {
			  if (this.right == null) {
				  this.right = newNode;
				  this.right.parent = this;
				  return true;
			  } else {
				  return this.right.insertNode(s);
			  }
		  }
	  }	  
	  return false;
  }
  
  
  public boolean removeNode(String s){ 
	
	  if (s.compareTo(this.data) < 0) {
		  return this.left.removeNode(s);
		  
	  }
	  if (s.compareTo(this.data) > 0) {
		  return this.right.removeNode(s);
	  }	 
	  if (s.equals(this.data)) {
		  if (this.left == null && this.right == null) {
			  if (this.data.compareTo(this.parent.data) > 0) {
				  this.parent.right = null;
			  }
			  if (this.data.compareTo(this.parent.data) < 0) {
				  this.parent.left = null;
			  }
			  if (this.data.compareTo(this.parent.data) == 0) {
				  this.parent.right = null;
			  }
			  return true;			  
		  }
		  if (this.left == null && this.right != null) {
			  if (this.data.compareTo(this.parent.data) > 0) {
				  this.parent.right = this.right;
				  this.right.parent = this.parent;
			  }
			  if (this.data.compareTo(this.parent.data) < 0) {
				  this.parent.left = this.right;
				  this.right.parent = this.parent;
			  }
			return true;			
		  }
		  if (this.right == null && this.left != null) {
			  if (this.data.compareTo(this.parent.data) > 0) {
				  this.parent.right = this.left;
				  this.left.parent = this.parent;
			  }
			  if (this.data.compareTo(this.parent.data) < 0) {
				  this.parent.left = this.left;
				  this.left.parent = this.parent;
			  }
			  return true;
		  }
		  if (this.left != null && this.right != null) {
			  this.data = this.right.findMin().data;
			  this.right.removeNode(this.data);	
			  return true;
		  }
	  }
	  
	  return true; 
	  	  
  }
  
  
  public BST_Node findMin(){ 
	  if (this.left == null) {
		  return this;
	  } else {
		  return this.left.findMin();
	  }	  
  }
  
  
  public BST_Node findMax(){ 
	  if (this.right == null) {
		  return this;
	  } else {
		  return this.right.findMax();
	  }	  
  }
  
  
  public int getHeight(){ 
	  
	  if (this.left == null && this.right == null) {
		  return 0;
	  }	  
	  if (this.left != null && this.right == null) {
		   return this.left.getHeight()+ 1;
	  } else if (this.right != null && this.left == null) {
		  return this.right.getHeight() + 1;
	  } else if (this.left != null && this.right != null) {
		  return Math.max(this.right.getHeight(), this.left.getHeight()) + 1;
	  }
	 
	  return 0;
	  
	  
  }
  
 
  // --- end fill in these methods --------------------------------------


  // --------------------------------------------------------------------
  // you may add any other methods you want to get the job done
  // --------------------------------------------------------------------
  
  public String toString(){
    return "Data: "+this.data+", Left: "+((this.left!=null)?left.data:"null")
            +",Right: "+((this.right!=null)?right.data:"null");
  }
}