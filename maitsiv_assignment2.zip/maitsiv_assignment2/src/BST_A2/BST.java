package BST_A2;

public class BST implements BST_Interface {
  public BST_Node root;
  int size;
  
  public BST(){ size=0; root=null; }
  
  @Override
  //used for testing, please leave as is
  public BST_Node getRoot(){ return root; }

@Override
public boolean insert(String s) {
	if (this.root == null) {
		BST_Node newNode = new BST_Node(s);
		this.root = newNode;
		this.size++;
		return true;
	} else {
		boolean insert = this.root.insertNode(s);
		if (insert) {
			this.size++;
		}
		return insert;
	}
}

@Override
public boolean remove(String s) {
	if (this.size == 0 || this.root == null) {
		return false;
	}
	 if (this.contains(s) == false) {
		  return false;
	}
	if (this.root.data == s) {
		if (this.root.left == null && this.root.right == null) {
			this.root = null;
			this.size--;
			return true;
		}
		else if (this.root.left == null || this.root.right == null) {
			if (this.root.left != null) {
				this.root = this.root.left;
			} else if (this.root.right != null) {
				this.root = this.root.right;
			}
			this.size--;	
			return true;		
		} else {
			this.root.data = this.root.right.findMin().data;
			this.root.right.removeNode(this.root.data);	
			this.size--;
		}

} else {
	boolean remove = this.root.removeNode(s);
	if (remove) {
		this.size--;
		return remove;
	}
}
return false;
}

@Override
public String findMin() {
	if (this.size == 0 || this.root == null) {
		return null;
	}
	return root.findMin().data;
}

@Override
public String findMax() {
	if (this.size == 0 || this.root == null) {
		return null;
	}
	return root.findMax().data;
}

@Override
public boolean empty() {
	if (this.root == null || this.size == 0) {
		return true;
	}
	return false;
}

@Override
public boolean contains(String s) {
	if (this.size == 0 || this.root == null) {
		return false;
	}
	return root.containsNode(s);
}

@Override
public int size() {
	if (this.root == null) {
		return 0;
	}
	
	return this.size;
}

@Override
public int height() {
	if (this.size == 0 || this.root == null) {
		return -1;
	} else {
		return this.root.getHeight();
	}
	
}



}